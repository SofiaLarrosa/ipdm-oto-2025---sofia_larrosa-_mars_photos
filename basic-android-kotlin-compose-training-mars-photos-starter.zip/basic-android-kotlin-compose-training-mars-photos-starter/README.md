2. Cómo agregar el repositorio y la inserción manual de dependencias

3. Cómo cargar y mostrar imágenes de Internet